"""QITP Agents — POC agent handlers for the Quantitative Investment Trading Platform."""

__version__ = "0.1.0"
