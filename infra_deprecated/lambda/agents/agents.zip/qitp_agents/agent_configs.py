"""QITP agent configurations — per-agent prompt builders and validation rules."""
from __future__ import annotations

import json
from typing import Any

from agent_core import AgentConfig, AgentConfigRegistry

AGENT_CONFIG_REGISTRY = AgentConfigRegistry()


# --- Gap Detector ---

def _gap_detector_prompt(params: dict[str, Any], idem_key: str) -> str:
    return (
        f"Analyze price gaps for watchlist '{params.get('watchlist_id', 'default')}' on {params['date']}.\n"
        f"Gap threshold: {params.get('threshold_pct', 2.0)}%.\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="gap-detector",
    operation_name="detect_gaps",
    required_fields=["date"],
    build_prompt=_gap_detector_prompt,
    defaults={"threshold_pct": 2.0, "watchlist_id": "default"},
))


# --- Sentiment Analyzer ---

def _sentiment_analyzer_prompt(params: dict[str, Any], idem_key: str) -> str:
    symbols = params["symbols"]
    symbols_str = ", ".join(symbols) if isinstance(symbols, list) else str(symbols)
    prompt = (
        f"Analyze sentiment for the following symbols on {params['date']}: {symbols_str}\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )
    gap_artifact = params.get("gap_results_artifact_id")
    if gap_artifact:
        prompt += (
            f"\nContext: Gap detection results are in artifact {gap_artifact}. "
            f"Cross-reference sentiment with gap direction for confirmation signals.\n"
        )
    return prompt

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="sentiment-analyzer",
    operation_name="analyze_sentiment",
    required_fields=["symbols", "date"],
    build_prompt=_sentiment_analyzer_prompt,
))


# --- Strategy Evaluator ---

def _strategy_evaluator_prompt(params: dict[str, Any], idem_key: str) -> str:
    return (
        f"Evaluate trading strategies for {params['symbol']} on {params['date']}.\n\n"
        f"## Gap Data (from gap detector)\n"
        f"{json.dumps(params.get('gap_data', {}), indent=2)}\n\n"
        f"## Sentiment Data (from sentiment analyzer)\n"
        f"{json.dumps(params.get('sentiment_data', {}), indent=2)}\n\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="strategy-evaluator",
    operation_name="evaluate_strategies",
    required_fields=["symbol", "date"],
    build_prompt=_strategy_evaluator_prompt,
))


# --- Portfolio Recommender ---

def _portfolio_recommender_prompt(params: dict[str, Any], idem_key: str) -> str:
    strategy_evaluations = params.get("strategy_evaluations", [])
    evals_json = json.dumps(strategy_evaluations, indent=2)
    prompt = (
        f"Today is {params['date']}.\n\n"
        f"## Strategy Evaluations from Pipeline\n{evals_json}\n\n"
        f"Apply your scoring formula and portfolio constraints as defined in your system prompt.\n\n"
    )
    gap_artifact = params.get("gap_results_artifact_id")
    sentiment_artifact = params.get("sentiment_report_artifact_id")
    if gap_artifact:
        prompt += (
            f"## Additional Data\n"
            f"Retrieve gap detection results from artifact: {gap_artifact}\n"
        )
    if sentiment_artifact:
        prompt += f"Retrieve sentiment report from artifact: {sentiment_artifact}\n"
    if gap_artifact or sentiment_artifact:
        prompt += "\n"
    prompt += f"Use idempotency key for artifact writes: {idem_key}\n"
    return prompt

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="portfolio-recommender",
    operation_name="recommend_portfolio",
    required_fields=["date", "strategy_evaluations"],
    build_prompt=_portfolio_recommender_prompt,
))


# --- ML Predictor ---

def _ml_predictor_prompt(params: dict[str, Any], idem_key: str) -> str:
    symbols = params["symbols"]
    symbols_str = ", ".join(symbols) if isinstance(symbols, list) else str(symbols)
    features = params.get("features_by_symbol", {})
    features_json = json.dumps(features, indent=2) if features else "Not provided"
    prompt = (
        f"Generate ML predictions for the following symbols on {params['date']}: {symbols_str}\n\n"
        f"## Pre-computed Features\n{features_json}\n\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )
    gap_artifact = params.get("gap_results_artifact_id")
    sentiment_artifact = params.get("sentiment_results_artifact_id")
    if gap_artifact:
        prompt += f"\nContext: Gap detection results in artifact {gap_artifact}.\n"
    if sentiment_artifact:
        prompt += f"Context: Sentiment results in artifact {sentiment_artifact}.\n"
    return prompt

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="ml-predictor",
    operation_name="predict",
    required_fields=["symbols", "date"],
    build_prompt=_ml_predictor_prompt,
))


# --- Technical Analyzer ---

def _technical_analyzer_prompt(params: dict[str, Any], idem_key: str) -> str:
    symbols = params["symbols"]
    symbols_str = ", ".join(symbols) if isinstance(symbols, list) else str(symbols)
    lookback = params.get("lookback_days", 200)
    return (
        f"Compute technical analysis for the following symbols on {params['date']}: {symbols_str}\n"
        f"Use a lookback period of {lookback} days for indicator computation.\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="technical-analyzer",
    operation_name="analyze_technicals",
    required_fields=["symbols", "date"],
    build_prompt=_technical_analyzer_prompt,
    defaults={"lookback_days": 200},
))


# --- Watchlist Screener ---

def _watchlist_screener_prompt(params: dict[str, Any], idem_key: str) -> str:
    universes = params.get("universes", ["sp500"])
    universes_str = ", ".join(universes) if isinstance(universes, list) else str(universes)
    lookback_months = params.get("lookback_months", 6)
    top_n = params.get("top_n", 20)
    # FilterConfig handling: use raw values, agent interprets
    filter_config = params.get("filter_config", {})
    min_market_cap = filter_config.get("min_market_cap_usd", 1_000_000_000)
    min_volume = filter_config.get("min_avg_daily_volume", 500_000)
    return (
        f"Screen stock universes for gap trading candidates.\n\n"
        f"Parameters:\n"
        f"- Universes: {universes_str}\n"
        f"- Lookback period: {lookback_months} months from {params['date']}\n"
        f"- Target candidates: top {top_n}\n"
        f"- Min market cap: ${min_market_cap / 1e9:.1f}B\n"
        f"- Min avg daily volume: {min_volume:,}\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="watchlist-screener",
    operation_name="screen_watchlist",
    required_fields=["date"],
    build_prompt=_watchlist_screener_prompt,
    defaults={"universes": ["sp500"], "lookback_months": 6, "top_n": 20},
))


# --- Tax Reporter ---

def _tax_reporter_prompt(params: dict[str, Any], idem_key: str) -> str:
    return (
        f"Generate the Spanish IRPF tax report for fiscal year {params['fiscal_year']}.\n"
        f"Load trading history from artifact '{params['trading_history_artifact_id']}'.\n"
        f"Output format: {params.get('output_format', 'json')}\n"
        f"Use idempotency key for artifact writes: {idem_key}\n"
    )

AGENT_CONFIG_REGISTRY.register(AgentConfig(
    agent_id="tax-reporter",
    operation_name="generate_tax_report",
    required_fields=["fiscal_year", "trading_history_artifact_id"],
    build_prompt=_tax_reporter_prompt,
    defaults={"output_format": "json"},
))
