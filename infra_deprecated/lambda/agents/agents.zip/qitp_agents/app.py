"""QITP agent application — wires platform GenericHandler with domain configs."""
from __future__ import annotations

import os
from pathlib import Path

from agent_core import BlueprintLoader, GenericHandler, IdempotencyStore, SessionManager

from qitp_agents.agent_configs import AGENT_CONFIG_REGISTRY
from qitp_agents.registries import HOOK_REGISTRY, SCHEMA_REGISTRY
from qitp_agents.execution import get_qitp_execution_mode, register_qitp_aliases
from qitp_agents.mcp_registry import create_mcp_client_from_registry

register_qitp_aliases()

_PROMPTS_DIR = str(Path(__file__).resolve().parents[2] / "prompts")

HANDLER = GenericHandler(
    loader=BlueprintLoader(
        blueprints_dir=os.environ.get("BLUEPRINTS_DIR", "blueprints"),
        prompt_dir=os.environ.get("PROMPTS_DIR", _PROMPTS_DIR),
        mcp_factory=create_mcp_client_from_registry,
        hook_registry=HOOK_REGISTRY,
        schema_registry=SCHEMA_REGISTRY,
    ),
    config_registry=AGENT_CONFIG_REGISTRY,
    idempotency_store=IdempotencyStore(),
    session_manager=SessionManager(),
)


def handler(event: dict, context=None) -> dict:
    """QITP generic Lambda handler."""
    return HANDLER.handle(event, context)


# AgentCoreApp wired to GenericHandler for AgentCore Runtime usage
from agent_core.runtime.entrypoint import AgentCoreApp

app = AgentCoreApp(handler=HANDLER)
