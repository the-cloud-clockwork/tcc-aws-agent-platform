"""QITP execution mode utilities.

Maps trading vocabulary (backtest/paper/live) to platform modes
(simulation/staging/production). All domain-specific terminology
lives here, not in agent-core.
"""
from __future__ import annotations

from agent_core import ExecutionMode, get_execution_mode
from agent_core.schemas.execution_modes import ExecutionModes

# QITP domain aliases → platform canonical names
QITP_MODE_ALIASES: dict[str, str] = {
    "backtest": "simulation",
    "paper": "staging",
    "live": "production",
}

_REVERSE: dict[str, str] = {v: k for k, v in QITP_MODE_ALIASES.items()}


def get_qitp_execution_mode() -> ExecutionMode:
    """Read EXECUTION_MODE, resolving QITP aliases (backtest/paper/live)."""
    return get_execution_mode(aliases=QITP_MODE_ALIASES)


def domain_name(mode: ExecutionMode) -> str:
    """Return the QITP-friendly name for a platform mode."""
    return _REVERSE.get(mode.value, mode.value)


def register_qitp_aliases() -> None:
    """Register QITP field aliases on ExecutionModes for YAML loading.

    Call once at startup before loading blueprints.
    """
    ExecutionModes.field_aliases = QITP_MODE_ALIASES
