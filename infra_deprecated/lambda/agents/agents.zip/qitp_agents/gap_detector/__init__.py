"""Gap Detection Agent — identifies and ranks price gaps."""
