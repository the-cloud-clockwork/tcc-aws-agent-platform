"""QITP domain hooks."""
