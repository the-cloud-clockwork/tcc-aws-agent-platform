"""Portfolio constraint hook — truncates excess recommendations."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class ConstraintHook:
    """Enforces max recommendation count on portfolio output.

    Safety net: the system prompt already enforces constraints,
    this hook truncates if the agent overshoots.
    """

    max_recommendations: int = 5  # Doc5: max 5 open positions

    def on_agent_end(
        self, result: dict[str, Any] | None = None, **kwargs: Any
    ) -> dict[str, Any] | None:
        if result is None:
            return None
        recs = result.get("recommendations")
        if isinstance(recs, list) and len(recs) > self.max_recommendations:
            logger.warning(
                "Trimming recommendations from %d to %d",
                len(recs),
                self.max_recommendations,
            )
            result["recommendations"] = recs[: self.max_recommendations]
        return result
