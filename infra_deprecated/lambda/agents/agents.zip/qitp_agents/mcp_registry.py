"""MCP client URL resolution for QITP agents.

Maps MCP server names (from blueprint YAML) to URLs via environment
variables with localhost defaults. Injected into BlueprintLoader as
the mcp_factory callable.

The generic MCP client factory (create_mcp_client) lives in agent-core.
"""

from __future__ import annotations

import logging
import os

from agent_core.tools.mcp_factory import create_mcp_client
from strands.tools.mcp import MCPClient

logger = logging.getLogger(__name__)


# MCP server URL resolution: name → (env_var, default_url)
MCP_SERVER_REGISTRY: dict[str, tuple[str, str]] = {
    "ibkr-mcp": ("IBKR_MCP_URI", "http://localhost:8001"),
    "market-data-mcp": ("MARKET_DATA_MCP_URI", "http://localhost:8002"),
    "sentiment-mcp": ("SENTIMENT_MCP_URI", "http://localhost:8003"),
    "artifacts-mcp": ("ARTIFACTS_MCP_URI", "http://localhost:8004"),
    "backtest-mcp": ("BACKTEST_MCP_URI", "http://localhost:8005"),
    "charting-mcp": ("CHARTING_MCP_URI", "http://localhost:8006"),
    "2fa-mcp": ("TWO_FA_MCP_URI", "http://localhost:8007"),
    "ml-predict-mcp": ("ML_PREDICT_MCP_URI", "http://localhost:8008"),
    "technical-mcp": ("TECHNICAL_MCP_URI", "http://localhost:8009"),
}


def create_mcp_client_from_registry(
    name: str,
    tool_filter: list[str] | None = None,
) -> MCPClient:
    """Resolve MCP server name to URL and create client.

    This is the mcp_factory injected into BlueprintLoader. When a blueprint
    YAML declares ``mcp: market-data-mcp``, the loader calls this function.

    URL resolution: env var > default localhost URL.
    """
    if name not in MCP_SERVER_REGISTRY:
        raise ValueError(f"Unknown MCP server: {name}. Available: {list(MCP_SERVER_REGISTRY.keys())}")
    env_var, default_url = MCP_SERVER_REGISTRY[name]
    url = os.environ.get(env_var, default_url)
    return create_mcp_client(name, url, tool_filter=tool_filter)
