"""ML Prediction Agent — XGBoost inference with SHAP explainability."""
