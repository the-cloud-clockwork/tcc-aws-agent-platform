"""Portfolio Recommender Agent — extended thinking for synthesis and portfolio construction."""
