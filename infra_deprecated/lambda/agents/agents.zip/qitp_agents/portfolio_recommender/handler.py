"""Portfolio Recommender Agent — delegates to QITP generic handler."""
import os
os.environ.setdefault("AGENT_ID", "portfolio-recommender")
from qitp_agents.app import handler  # noqa: E402, F401
