"""Domain registries — maps blueprint field values to implementations."""
from __future__ import annotations

from agent_core import CompositeObservabilityHook

from qitp_agents.hooks.constraints import ConstraintHook

from qitp_agents.schemas import (
    GapDetectionOutput,
    MLPredictionReport,
    PortfolioRecommendation,
    ScreenerOutput,
    SentimentReport,
    StrategyEvaluationOutput,
    TechnicalAnalysisReport,
)
from qitp_agents.tax_reporter.models import TaxReport

HOOK_REGISTRY: dict[str, type] = {
    "observability": CompositeObservabilityHook,
    "portfolio_constraints": ConstraintHook,
}

SCHEMA_REGISTRY: dict[str, type] = {
    "GapDetectionOutput": GapDetectionOutput,
    "SentimentReport": SentimentReport,
    "StrategyEvaluationOutput": StrategyEvaluationOutput,
    "PortfolioRecommendation": PortfolioRecommendation,
    "TechnicalAnalysisReport": TechnicalAnalysisReport,
    "MLPredictionReport": MLPredictionReport,
    "ScreenerOutput": ScreenerOutput,
    "TaxReport": TaxReport,
}
