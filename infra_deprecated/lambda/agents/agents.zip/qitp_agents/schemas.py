"""Output schema models for all QITP agents.

Each model matches the ``output_schema`` field declared in the corresponding
agent blueprint YAML.  Registered in ``SCHEMA_REGISTRY`` (registries.py) so
the engine can validate agent outputs at runtime.

Field names are aligned with the system prompt output spec AND the QITP doc
examples (Doc2 Section 6) so that LLM-produced JSON validates correctly.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Gap Detection Agent
# Doc2 example: ranked_gaps with symbol/name/friday_close/monday_open/gap_abs/
#   gap_pct/gap_direction/volume_ratio/sector/asset_type/market
# Doc2 top-level: date, scan_count, significant_gaps, threshold_pct,
#   execution_mode, artifact_id
# Prompt: ranked_gaps, total_gaps_found, analysis_date, artifact_id
# ---------------------------------------------------------------------------

class GapItem(BaseModel):
    symbol: str
    gap_pct: float
    direction: str = ""  # UP / DOWN (prompt uses "direction")
    gap_direction: str = ""  # up / down (doc uses "gap_direction")
    volume_ratio: float | None = None
    previous_close: float | None = None
    friday_close: float | None = None
    monday_open: float | None = None
    open_price: float | None = None
    gap_abs: float | None = None
    confidence: float | None = None
    name: str = ""
    sector: str = ""
    asset_type: str = ""
    market: str = ""


class GapDetectionOutput(BaseModel):
    ranked_gaps: list[GapItem] = Field(default_factory=list)
    analysis_date: str = ""
    date: str = ""  # doc alias
    watchlist_id: str = ""
    total_gaps_found: int = 0
    significant_gaps: int = 0  # doc alias
    scan_count: int = 0
    threshold_pct: float = 2.0
    execution_mode: str = ""
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# Sentiment Analysis Agent
# Doc2 example: date, macro{vix_level, fear_greed_index, regime,
#   sector_rotation}, per_ticker[]{symbol, sentiment_score, sentiment_label,
#   news_score, news_count, analyst_consensus, analyst_target,
#   analyst_upgrades_7d, earnings_upcoming, macro_alignment}
# Prompt: per_symbol_sentiments, overall_market_sentiment,
#         high_signal_symbols, artifact_id
# ---------------------------------------------------------------------------

class MacroContext(BaseModel):
    vix_level: float | None = None
    fear_greed_index: float | None = None
    regime: str = ""  # risk_on / risk_off / neutral
    sector_rotation: str = ""


class SymbolSentiment(BaseModel):
    symbol: str
    composite_score: float = 0.0
    sentiment_score: float = 0.0  # doc alias
    sentiment_label: str = ""  # bullish / bearish / neutral
    news_score: float | None = None
    social_score: float | None = None
    news_count: int = 0
    source_count: int = 0
    dominant_theme: str = ""
    analyst_consensus: str = ""
    analyst_target: float | None = None
    analyst_upgrades_7d: int = 0
    earnings_upcoming: bool = False
    macro_alignment: str = ""


class SentimentReport(BaseModel):
    per_symbol_sentiments: list[SymbolSentiment] = Field(default_factory=list)
    macro: MacroContext | None = None
    overall_market_sentiment: float | None = None
    high_signal_symbols: list[str] = Field(default_factory=list)
    analysis_date: str = ""
    date: str = ""  # doc alias
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# Strategy Evaluation Agent
# Prompt: symbol, date, evaluated_strategies (strategy_id, score,
#         matched_conditions, backtest_summary),
#         recommended_strategy_id, confidence, signals_used, artifact_id
# ---------------------------------------------------------------------------

class StrategyScore(BaseModel):
    strategy_id: str
    score: float = 0.0
    matched_conditions: list[str] = Field(default_factory=list)
    backtest_summary: dict | None = None
    strategy_confidence: float | None = None


class StrategyEvaluationOutput(BaseModel):
    symbol: str
    date: str
    evaluated_strategies: list[StrategyScore] = Field(default_factory=list)
    recommended_strategy_id: str | None = None
    confidence: float = 0.0
    signals_used: list[str] = Field(default_factory=list)
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# Portfolio Recommender Agent
# Doc2 example: date, execution_mode, market_conditions,
#   portfolio_constraints_applied, recommendations[]{symbol, action, strategy,
#   entry_price, position_size_eur, position_size_shares, trailing_stop_pct,
#   trailing_stop_price, expected_holding_days, composite_score, gap_score,
#   sentiment_score, strategy_confidence, rationale},
#   no_action_symbols[]{symbol, reason}
# Prompt: recommendations, no_action_symbols, portfolio_summary, artifact_id
# ---------------------------------------------------------------------------

class PositionRecommendation(BaseModel):
    symbol: str
    strategy_id: str = ""
    action: str = ""  # buy / sell (doc field)
    strategy: str = ""  # doc alias for strategy_id
    direction: str = ""  # LONG / SHORT
    composite_score: float = 0.0
    gap_score: float | None = None
    sentiment_score: float | None = None
    technical_score: float | None = None
    strategy_confidence: float | None = None
    suggested_position_size_pct: float = 0.0
    position_size_eur: float | None = None
    position_size_shares: int | None = None
    entry_price: float | None = None
    stop_loss: float | None = None
    take_profit: float | None = None
    trailing_stop_pct: float | None = None
    trailing_stop_price: float | None = None
    expected_holding_days: int | None = None
    confidence: float = 0.0
    rationale: str = ""


class NoActionItem(BaseModel):
    symbol: str
    reason: str


class PortfolioSummary(BaseModel):
    total_positions: int = 0
    total_allocation_pct: float = 0.0
    sector_breakdown: dict[str, float] = Field(default_factory=dict)


class PortfolioRecommendation(BaseModel):
    recommendations: list[PositionRecommendation] = Field(default_factory=list)
    no_action_symbols: list[NoActionItem] = Field(default_factory=list)
    portfolio_summary: PortfolioSummary = Field(default_factory=PortfolioSummary)
    date: str = ""
    execution_mode: str = ""
    market_conditions: str = ""
    portfolio_constraints_applied: bool = False
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# Technical Analysis Agent
# Prompt: technical_scores (composite_score, signal, confidence, indicators),
#         overall_market_technical_score, strong_technical, weak_technical,
#         artifact_id
# ---------------------------------------------------------------------------

class SymbolTechnicalScore(BaseModel):
    symbol: str
    composite_score: float = 0.0
    signal: str = ""  # bullish / bearish / neutral
    confidence: float = 0.0
    rsi: float | None = None
    macd_signal: str | None = None
    bollinger_position: str | None = None
    atr: float | None = None
    trend_alignment: str | None = None
    support: float | None = None
    resistance: float | None = None


class TechnicalAnalysisReport(BaseModel):
    technical_scores: list[SymbolTechnicalScore] = Field(default_factory=list)
    overall_market_technical_score: float | None = None
    strong_technical: list[str] = Field(default_factory=list)
    weak_technical: list[str] = Field(default_factory=list)
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# ML Prediction Agent
# Prompt: model_version, prediction_date, per_symbol_predictions,
#         symbols_bullish, symbols_bearish, composite_score_updates,
#         artifact_id
# ---------------------------------------------------------------------------

class SymbolPrediction(BaseModel):
    symbol: str
    direction: str = ""  # UP / DOWN
    confidence: float = 0.0
    ml_score: float = 0.0
    top_shap_features: list[dict] = Field(default_factory=list)


class MLPredictionReport(BaseModel):
    model_version: str = ""
    prediction_date: str = ""
    per_symbol_predictions: list[SymbolPrediction] = Field(default_factory=list)
    symbols_bullish: list[str] = Field(default_factory=list)
    symbols_bearish: list[str] = Field(default_factory=list)
    composite_score_updates: dict[str, float] = Field(default_factory=dict)
    artifact_id: str = ""


# ---------------------------------------------------------------------------
# Watchlist Screener Agent
# Prompt: candidates (symbol, name, market, sector, overall_score,
#         score_breakdown, gap_stats, recommendation),
#         screening_summary, artifact_id
# ---------------------------------------------------------------------------

class ScreenerCandidate(BaseModel):
    symbol: str
    name: str = ""
    market: str = ""
    sector: str = ""
    overall_score: float = 0.0
    score_breakdown: dict[str, float] = Field(default_factory=dict)
    gap_stats: dict = Field(default_factory=dict)
    recommendation: str = ""


class ScreeningSummary(BaseModel):
    universes_scanned: list[str] = Field(default_factory=list)
    total_symbols_analyzed: int = 0
    candidates_selected: int = 0


class ScreenerOutput(BaseModel):
    candidates: list[ScreenerCandidate] = Field(default_factory=list)
    screening_summary: ScreeningSummary = Field(default_factory=ScreeningSummary)
    artifact_id: str = ""
