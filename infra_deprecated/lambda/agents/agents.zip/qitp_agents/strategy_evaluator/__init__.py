"""Strategy Evaluation Agent — Graph pattern with deterministic edge routing."""
