"""Strategy Evaluation Agent — delegates to QITP generic handler."""
import os
os.environ.setdefault("AGENT_ID", "strategy-evaluator")
from qitp_agents.app import handler  # noqa: E402, F401
