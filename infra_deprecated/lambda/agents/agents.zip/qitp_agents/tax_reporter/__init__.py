"""Tax Reporter Agent — Spanish IRPF tax report generation from trading history."""
