"""Tax report formatters — CSV and structured JSON output.

Produces output suitable for:
- Manual review in spreadsheet (CSV)
- Import into tax software (structured JSON)
- Artifact storage via artifacts-mcp
"""

from __future__ import annotations

import csv
import io
import logging

from qitp_agents.tax_reporter.models import TaxReport

logger = logging.getLogger(__name__)


def format_as_csv(report: TaxReport) -> str:
    """Format capital gains as CSV for spreadsheet review.

    Columns follow AEAT Modelo 100 structure:
    Symbol, ISIN, Acquisition Date, Disposal Date, Days Held,
    Quantity, Acquisition EUR, Disposal EUR, Gain/Loss EUR,
    Loss Disallowed, Notes
    """
    output = io.StringIO()
    writer = csv.writer(output)

    # Header
    writer.writerow(
        [
            "Symbol",
            "ISIN",
            "Asset Type",
            "Acquisition Date",
            "Disposal Date",
            "Holding Period (days)",
            "Quantity",
            "Acquisition Price EUR",
            "Disposal Price EUR",
            "Gain/Loss EUR",
            "Is Gain",
            "Acq Commission EUR",
            "Disp Commission EUR",
            "Acq FX Rate",
            "Disp FX Rate",
            "Loss Disallowed",
            "Disallowed Reason",
        ]
    )

    # Capital gains rows
    for gain in report.capital_gains:
        writer.writerow(
            [
                gain.symbol,
                gain.isin or "",
                gain.asset_type.value,
                gain.acquisition_date.isoformat(),
                gain.disposal_date.isoformat(),
                gain.holding_period_days,
                gain.quantity,
                f"{gain.acquisition_price_eur:.2f}",
                f"{gain.disposal_price_eur:.2f}",
                f"{gain.gain_loss_eur:.2f}",
                gain.is_gain,
                f"{gain.acquisition_commission_eur:.2f}",
                f"{gain.disposal_commission_eur:.2f}",
                f"{gain.acquisition_fx_rate:.6f}",
                f"{gain.disposal_fx_rate:.6f}",
                gain.loss_disallowed,
                gain.loss_disallowed_reason or "",
            ]
        )

    # Blank row + dividends section
    if report.dividends:
        writer.writerow([])
        writer.writerow(["--- DIVIDENDS ---"])
        writer.writerow(
            [
                "Symbol",
                "Payment Date",
                "Gross EUR",
                "Withholding EUR",
                "Net EUR",
                "Country",
                "FX Rate",
            ]
        )
        for div in report.dividends:
            writer.writerow(
                [
                    div.symbol,
                    div.payment_date.isoformat(),
                    f"{div.gross_amount_eur:.2f}",
                    f"{div.withholding_tax_eur:.2f}",
                    f"{div.net_amount_eur:.2f}",
                    div.country_of_source,
                    f"{div.fx_rate:.6f}",
                ]
            )

    # Summary section
    writer.writerow([])
    writer.writerow(["--- SUMMARY ---"])
    s = report.summary
    writer.writerow(["Fiscal Year", s.fiscal_year])
    writer.writerow(["Total Gains EUR", f"{s.total_gains_eur:.2f}"])
    writer.writerow(["Total Losses EUR", f"{s.total_losses_eur:.2f}"])
    writer.writerow(["Net Gain/Loss EUR", f"{s.net_gain_loss_eur:.2f}"])
    writer.writerow(["Disallowed Losses EUR", f"{s.disallowed_losses_eur:.2f}"])
    writer.writerow(["Total Commissions EUR", f"{s.total_commissions_eur:.2f}"])
    writer.writerow(["Dividend Income EUR", f"{s.dividend_income_gross_eur:.2f}"])
    writer.writerow(["Dividend Withholding EUR", f"{s.dividend_withholding_eur:.2f}"])
    writer.writerow(["Estimated Tax EUR", f"{s.estimated_tax_eur:.2f}"])
    writer.writerow(["Transactions", s.num_transactions])

    return output.getvalue()


def format_as_json(report: TaxReport) -> str:
    """Format report as structured JSON for programmatic consumption."""
    return report.model_dump_json(indent=2)


def format_summary_text(report: TaxReport) -> str:
    """Format a human-readable summary of the tax report."""
    s = report.summary
    lines = [
        f"IRPF Tax Report -- Fiscal Year {s.fiscal_year}",
        "=" * 50,
        "",
        f"Capital Gains:     EUR {s.total_gains_eur:>12,.2f}",
        f"Capital Losses:    EUR {s.total_losses_eur:>12,.2f}",
        f"Net Gain/Loss:     EUR {s.net_gain_loss_eur:>12,.2f}",
        "",
    ]

    if s.disallowed_losses_eur != 0:
        lines.append(f"Disallowed Losses: EUR {s.disallowed_losses_eur:>12,.2f}")
        lines.append("  (Homogeneous securities rule -- Art. 33.5.f LIRPF)")
        lines.append("")

    lines.extend(
        [
            f"Dividend Income:   EUR {s.dividend_income_gross_eur:>12,.2f}",
            f"Withholding Tax:   EUR {s.dividend_withholding_eur:>12,.2f}",
            f"Total Commissions: EUR {s.total_commissions_eur:>12,.2f}",
            "",
            f"Estimated Tax:     EUR {s.estimated_tax_eur:>12,.2f}",
            "",
            "Tax Bracket Breakdown:",
        ]
    )

    for bracket in s.tax_bracket_breakdown:
        lines.append(
            f"  EUR {bracket['bracket_from']:>10,.0f} - {bracket['bracket_to']:>10,.0f} "
            f"@ {bracket['rate'] * 100:.0f}%: EUR {bracket['tax']:>10,.2f}"
        )

    lines.extend(
        [
            "",
            f"Transactions: {s.num_transactions} ({s.num_capital_gains} gains, {s.num_capital_losses} losses)",
        ]
    )

    if report.warnings:
        lines.extend(["", "WARNINGS:"])
        for w in report.warnings:
            lines.append(f"  - {w}")

    return "\n".join(lines)
