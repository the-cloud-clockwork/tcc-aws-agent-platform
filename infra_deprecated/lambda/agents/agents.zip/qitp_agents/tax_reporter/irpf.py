"""Spanish IRPF capital gains calculation engine.

Implements FIFO lot matching, multi-currency conversion,
homogeneous securities anti-avoidance rules, and tax bracket computation.
"""

from __future__ import annotations

import logging
from collections import defaultdict, deque
from datetime import date, timedelta

from qitp_agents.tax_reporter.models import (
    AssetType,
    CapitalGain,
    DividendIncome,
    TaxLot,
    TaxReport,
    TaxSummary,
)

logger = logging.getLogger(__name__)

# Spanish savings income tax brackets (2025/2026)
SAVINGS_TAX_BRACKETS: list[tuple[float, float]] = [
    (6_000.0, 0.19),  # First EUR 6,000 at 19%
    (50_000.0, 0.21),  # EUR 6,001 - 50,000 at 21%
    (200_000.0, 0.23),  # EUR 50,001 - 200,000 at 23%
    (300_000.0, 0.27),  # EUR 200,001 - 300,000 at 27%
    (float("inf"), 0.28),  # Over EUR 300,000 at 28%
]

# Homogeneous securities rule: 2 months for listed, 1 year for unlisted
HOMOGENEOUS_SECURITIES_WINDOW_DAYS = 60  # 2 months for listed securities


class IRPFCalculator:
    """IRPF capital gains calculator using FIFO lot matching.

    Usage:
        calc = IRPFCalculator(fiscal_year=2025)
        calc.add_buy(...)   # Add all buys
        calc.add_sell(...)  # Add all sells — triggers FIFO matching
        report = calc.generate_report()
    """

    def __init__(self, fiscal_year: int) -> None:
        self._fiscal_year = fiscal_year
        # FIFO queues per symbol
        self._lots: dict[str, deque[TaxLot]] = defaultdict(deque)
        self._capital_gains: list[CapitalGain] = []
        self._dividends: list[DividendIncome] = []
        self._lot_counter = 0
        self._total_commissions = 0.0
        # Track sells for homogeneous securities rule
        self._recent_sells: dict[str, list[date]] = defaultdict(list)
        self._recent_buys: dict[str, list[date]] = defaultdict(list)
        self._warnings: list[str] = []

    def add_buy(
        self,
        symbol: str,
        buy_date: date,
        quantity: float,
        price_local: float,
        price_eur: float,
        fx_rate: float,
        currency: str,
        asset_type: AssetType = AssetType.EQUITY,
        exchange: str = "",
        isin: str | None = None,
        commission_eur: float = 0.0,
    ) -> TaxLot:
        """Record a buy transaction — creates a new FIFO lot."""
        self._lot_counter += 1
        lot = TaxLot(
            lot_id=f"LOT-{self._lot_counter:06d}",
            symbol=symbol,
            asset_type=asset_type,
            acquisition_date=buy_date,
            acquisition_price_local=price_local,
            acquisition_price_eur=price_eur,
            acquisition_fx_rate=fx_rate,
            quantity=quantity,
            remaining_quantity=quantity,
            currency=currency,
            exchange=exchange,
            isin=isin,
            commission_eur=commission_eur,
        )

        self._lots[symbol].append(lot)
        self._total_commissions += commission_eur
        self._recent_buys[symbol].append(buy_date)

        return lot

    def add_sell(
        self,
        symbol: str,
        sell_date: date,
        quantity: float,
        _price_local: float,
        price_eur: float,
        fx_rate: float,
        commission_eur: float = 0.0,
    ) -> list[CapitalGain]:
        """Record a sell transaction — matches against FIFO lots.

        Args:
            symbol: Symbol sold.
            sell_date: Date of sale.
            quantity: Number of shares/units sold.
            _price_local: Sell price per unit in local currency (unused; EUR price used for tax calc).
            price_eur: Sell price per unit in EUR.
            fx_rate: FX rate on sell date.
            commission_eur: Sell commission in EUR.

        Returns:
            List of CapitalGain records (one per matched lot).
        """
        self._total_commissions += commission_eur
        self._recent_sells[symbol].append(sell_date)

        gains: list[CapitalGain] = []
        remaining_qty = quantity
        lots = self._lots.get(symbol, deque())

        # Distribute commission proportionally across matched lots
        commission_per_unit = commission_eur / quantity if quantity > 0 else 0.0

        while remaining_qty > 0 and lots:
            lot = lots[0]

            if lot.remaining_quantity <= 0:
                lots.popleft()
                continue

            match_qty = min(remaining_qty, lot.remaining_quantity)
            lot.remaining_quantity -= match_qty
            remaining_qty -= match_qty

            # Calculate capital gain for this lot match
            acquisition_total_eur = (
                lot.acquisition_price_eur * match_qty
                + (lot.commission_eur * match_qty / lot.quantity)  # Pro-rata acquisition commission
            )
            disposal_total_eur = (
                price_eur * match_qty - commission_per_unit * match_qty  # Pro-rata disposal commission
            )
            gain_loss = disposal_total_eur - acquisition_total_eur

            holding_days = (sell_date - lot.acquisition_date).days

            # Check homogeneous securities rule
            loss_disallowed = False
            loss_disallowed_reason = None
            if gain_loss < 0:
                loss_disallowed, loss_disallowed_reason = self._check_homogeneous_rule(
                    symbol,
                    sell_date,
                )

            gain = CapitalGain(
                symbol=symbol,
                asset_type=lot.asset_type,
                isin=lot.isin,
                acquisition_date=lot.acquisition_date,
                disposal_date=sell_date,
                holding_period_days=holding_days,
                quantity=match_qty,
                acquisition_price_eur=round(acquisition_total_eur, 2),
                disposal_price_eur=round(disposal_total_eur, 2),
                gain_loss_eur=round(gain_loss, 2),
                is_gain=gain_loss > 0,
                acquisition_commission_eur=round(lot.commission_eur * match_qty / lot.quantity, 2),
                disposal_commission_eur=round(commission_per_unit * match_qty, 2),
                acquisition_fx_rate=lot.acquisition_fx_rate,
                disposal_fx_rate=fx_rate,
                lot_id=lot.lot_id,
                loss_disallowed=loss_disallowed,
                loss_disallowed_reason=loss_disallowed_reason,
            )

            self._capital_gains.append(gain)
            gains.append(gain)

            if lot.remaining_quantity <= 0:
                lots.popleft()

        if remaining_qty > 0:
            self._warnings.append(
                f"Sold {quantity} of {symbol} on {sell_date} but only matched "
                f"{quantity - remaining_qty}. Possible short sale or missing buy data."
            )

        return gains

    def add_dividend(self, dividend: DividendIncome) -> None:
        """Record a dividend payment."""
        self._dividends.append(dividend)

    def _check_homogeneous_rule(self, symbol: str, sell_date: date) -> tuple[bool, str | None]:
        """Check the homogeneous securities anti-avoidance rule.

        If the investor sells at a loss and repurchases the same security
        within 2 months before or after the sale, the loss is disallowed
        and added to the cost basis of the new acquisition.

        Returns:
            (is_disallowed, reason_string)
        """
        window_start = sell_date - timedelta(days=HOMOGENEOUS_SECURITIES_WINDOW_DAYS)
        window_end = sell_date + timedelta(days=HOMOGENEOUS_SECURITIES_WINDOW_DAYS)

        recent_buys = self._recent_buys.get(symbol, [])
        for buy_date in recent_buys:
            if window_start <= buy_date <= window_end and buy_date != sell_date:
                return (
                    True,
                    f"Repurchase of {symbol} on {buy_date} within 2-month window "
                    f"of loss sale on {sell_date} (Art. 33.5.f LIRPF)",
                )

        return (False, None)

    def compute_tax(self, net_gain: float) -> tuple[float, list[dict[str, float]]]:
        """Compute estimated tax on net capital gains using savings brackets.

        Args:
            net_gain: Net capital gain in EUR (after offsetting losses).

        Returns:
            (total_tax, bracket_breakdown)
        """
        if net_gain <= 0:
            return (0.0, [])

        remaining = net_gain
        total_tax = 0.0
        breakdown: list[dict[str, float]] = []
        prev_threshold = 0.0

        for threshold, rate in SAVINGS_TAX_BRACKETS:
            bracket_size = threshold - prev_threshold
            taxable_in_bracket = min(remaining, bracket_size)

            if taxable_in_bracket <= 0:
                break

            tax = taxable_in_bracket * rate
            total_tax += tax
            breakdown.append(
                {
                    "bracket_from": prev_threshold,
                    "bracket_to": prev_threshold + taxable_in_bracket,
                    "rate": rate,
                    "taxable_amount": round(taxable_in_bracket, 2),
                    "tax": round(tax, 2),
                }
            )

            remaining -= taxable_in_bracket
            prev_threshold = threshold

        return (round(total_tax, 2), breakdown)

    def generate_report(self) -> TaxReport:
        """Generate the complete IRPF tax report.

        Returns:
            TaxReport with all capital gains, dividends, summary, and estimates.
        """
        from datetime import UTC, datetime

        # Filter capital gains for this fiscal year
        year_gains = [g for g in self._capital_gains if g.disposal_date.year == self._fiscal_year]

        total_gains = sum(g.gain_loss_eur for g in year_gains if g.is_gain)
        total_losses = sum(g.gain_loss_eur for g in year_gains if not g.is_gain)
        disallowed = sum(abs(g.gain_loss_eur) for g in year_gains if g.loss_disallowed)
        # Disallowed losses are not deductible
        net = total_gains + total_losses + disallowed

        dividend_gross = sum(d.gross_amount_eur for d in self._dividends)
        dividend_withholding = sum(d.withholding_tax_eur for d in self._dividends)

        # Total savings base includes capital gains + dividends
        total_savings_base = max(0, net) + dividend_gross
        estimated_tax, bracket_breakdown = self.compute_tax(total_savings_base)
        # Credit for withholding tax already paid
        estimated_tax = max(0, estimated_tax - dividend_withholding)

        # Open lots at year end
        open_lots = []
        for symbol, lots in self._lots.items():
            for lot in lots:
                if lot.remaining_quantity > 0:
                    open_lots.append(lot)

        summary = TaxSummary(
            fiscal_year=self._fiscal_year,
            total_gains_eur=round(total_gains, 2),
            total_losses_eur=round(total_losses, 2),
            net_gain_loss_eur=round(net, 2),
            disallowed_losses_eur=round(disallowed, 2),
            total_commissions_eur=round(self._total_commissions, 2),
            dividend_income_gross_eur=round(dividend_gross, 2),
            dividend_withholding_eur=round(dividend_withholding, 2),
            estimated_tax_eur=round(estimated_tax, 2),
            tax_bracket_breakdown=bracket_breakdown,
            num_transactions=len(year_gains),
            num_capital_gains=sum(1 for g in year_gains if g.is_gain),
            num_capital_losses=sum(1 for g in year_gains if not g.is_gain),
        )

        return TaxReport(
            fiscal_year=self._fiscal_year,
            generated_at=datetime.now(UTC),
            summary=summary,
            capital_gains=year_gains,
            dividends=self._dividends,
            tax_lots_open=open_lots,
            warnings=self._warnings,
        )
