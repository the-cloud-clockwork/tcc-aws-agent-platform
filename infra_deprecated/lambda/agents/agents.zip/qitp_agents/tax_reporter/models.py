"""Tax report data models.

Implements Spanish IRPF tax structures for capital gains from
financial instrument trading. Follows AEAT Modelo 100 requirements.
"""

from __future__ import annotations

from datetime import date, datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class AssetType(StrEnum):
    """Financial asset types for tax classification."""

    EQUITY = "equity"
    ETF = "etf"
    CFD = "cfd"
    CRYPTO = "crypto"
    FUND = "fund"


class TransactionType(StrEnum):
    """Transaction types."""

    BUY = "buy"
    SELL = "sell"
    DIVIDEND = "dividend"
    INTEREST = "interest"
    FX_CONVERSION = "fx_conversion"


class TaxLot(BaseModel):
    """A tax lot representing a specific acquisition of shares/units.

    FIFO (First In First Out) is mandatory in Spain for capital gains calculation.
    Each buy creates a new lot; each sell consumes lots in FIFO order.
    """

    lot_id: str
    symbol: str
    asset_type: AssetType
    acquisition_date: date
    acquisition_price_local: float  # Price in instrument currency
    acquisition_price_eur: float  # Price converted to EUR at acquisition date rate
    acquisition_fx_rate: float  # FX rate on acquisition date (1 local = X EUR)
    quantity: float
    remaining_quantity: float  # Quantity not yet disposed
    currency: str  # Instrument currency (USD, EUR, JPY, etc.)
    exchange: str
    isin: str | None = None  # ISIN for MiFID II compliance
    commission_eur: float = 0.0  # Acquisition commission in EUR


class CapitalGain(BaseModel):
    """A single capital gain/loss from disposing of a tax lot.

    Spanish IRPF distinguishes:
    - Short-term: acquisition to disposal < 1 year (taxed as savings income)
    - Long-term: >= 1 year (also savings income, same rates in Spain)

    Tax rates for savings income (rentas del ahorro) 2025:
    - First EUR 6,000: 19%
    - EUR 6,001 - 50,000: 21%
    - EUR 50,001 - 200,000: 23%
    - EUR 200,001 - 300,000: 27%
    - Over EUR 300,000: 28%
    """

    symbol: str
    asset_type: AssetType
    isin: str | None = None
    acquisition_date: date
    disposal_date: date
    holding_period_days: int
    quantity: float
    acquisition_price_eur: float  # Total cost basis in EUR (price * qty + commission)
    disposal_price_eur: float  # Total proceeds in EUR (price * qty - commission)
    gain_loss_eur: float  # disposal_price_eur - acquisition_price_eur
    is_gain: bool  # True if gain_loss_eur > 0
    acquisition_commission_eur: float = 0.0
    disposal_commission_eur: float = 0.0
    acquisition_fx_rate: float = 1.0
    disposal_fx_rate: float = 1.0
    lot_id: str | None = None

    # Anti-avoidance: Spanish law prohibits claiming a loss if you
    # repurchase the same asset within 2 months (homogeneous securities rule)
    loss_disallowed: bool = False
    loss_disallowed_reason: str | None = None


class DividendIncome(BaseModel):
    """Dividend income record for tax reporting."""

    symbol: str
    payment_date: date
    gross_amount_local: float
    gross_amount_eur: float
    withholding_tax_local: float  # Tax withheld at source
    withholding_tax_eur: float
    net_amount_eur: float
    country_of_source: str  # For double taxation treaty claims
    fx_rate: float = 1.0


class TaxSummary(BaseModel):
    """Aggregated tax summary for the fiscal year."""

    fiscal_year: int
    total_gains_eur: float
    total_losses_eur: float
    net_gain_loss_eur: float
    disallowed_losses_eur: float  # Losses blocked by homogeneous securities rule
    total_commissions_eur: float
    dividend_income_gross_eur: float
    dividend_withholding_eur: float
    estimated_tax_eur: float  # Estimated tax liability
    tax_bracket_breakdown: list[dict[str, float]]  # Per-bracket amounts
    num_transactions: int
    num_capital_gains: int
    num_capital_losses: int


class TaxReport(BaseModel):
    """Complete IRPF tax report for a fiscal year.

    Contains all the data needed to complete Modelo 100 sections:
    - Box 0328-0339: Capital gains from financial instruments
    - Box 0029: Dividend income
    - Box 0588: Foreign tax credits
    """

    fiscal_year: int
    generated_at: datetime
    taxpayer_id: str | None = None  # NIF/NIE — NOT stored, passed at generation time
    summary: TaxSummary
    capital_gains: list[CapitalGain]
    dividends: list[DividendIncome] = Field(default_factory=list)
    tax_lots_open: list[TaxLot] = Field(default_factory=list)  # Lots still held at year end
    warnings: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
