"""Technical Analysis Agent — computes indicators and technical scores for symbols."""
