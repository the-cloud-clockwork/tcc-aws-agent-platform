"""Watchlist Screener Agent — AI-powered stock universe scanning for gap candidates."""
