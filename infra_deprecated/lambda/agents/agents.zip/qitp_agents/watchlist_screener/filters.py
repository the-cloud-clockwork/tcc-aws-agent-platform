"""Screening filters for watchlist candidate selection.

Each filter is a callable that takes a list of UniverseSymbol and returns
a filtered subset. Filters are composable and order-independent.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

from qitp_agents.watchlist_screener.universe import UniverseSymbol

logger = logging.getLogger(__name__)


@dataclass
class FilterConfig:
    """Configuration for screening filters."""

    min_market_cap_usd: float = 1_000_000_000  # $1B minimum
    max_market_cap_usd: float | None = None
    min_avg_daily_volume: int = 1_000_000  # 1M shares/day minimum
    allowed_markets: list[str] = field(default_factory=lambda: ["us", "eu", "jp", "hk", "crypto"])
    allowed_sectors: list[str] | None = None  # None = all sectors
    excluded_sectors: list[str] = field(default_factory=list)
    allowed_asset_types: list[str] = field(default_factory=lambda: ["stock", "etf", "crypto"])
    exclude_symbols: list[str] = field(default_factory=list)  # Already on watchlist
    max_candidates: int = 200


def apply_liquidity_filter(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Filter by minimum average daily volume.

    Illiquid stocks produce unreliable gap signals due to wide spreads
    and low fill probability.
    """
    filtered = [s for s in symbols if s.avg_daily_volume >= config.min_avg_daily_volume]
    logger.info(
        "Liquidity filter: %d -> %d (min_volume=%d)",
        len(symbols),
        len(filtered),
        config.min_avg_daily_volume,
    )
    return filtered


def apply_market_cap_filter(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Filter by market capitalization range.

    Micro/small caps excluded by default — too volatile, unreliable gaps.
    """
    filtered = []
    for s in symbols:
        if s.market_cap_usd < config.min_market_cap_usd:
            continue
        if config.max_market_cap_usd and s.market_cap_usd > config.max_market_cap_usd:
            continue
        filtered.append(s)

    logger.info(
        "Market cap filter: %d -> %d (min=$%.0fB)",
        len(symbols),
        len(filtered),
        config.min_market_cap_usd / 1e9,
    )
    return filtered


def apply_sector_filter(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Filter by allowed/excluded sectors.

    Supports both allowlist and blocklist modes.
    """
    filtered = symbols

    if config.allowed_sectors:
        filtered = [s for s in filtered if s.sector in config.allowed_sectors]

    if config.excluded_sectors:
        filtered = [s for s in filtered if s.sector not in config.excluded_sectors]

    logger.info("Sector filter: %d -> %d", len(symbols), len(filtered))
    return filtered


def apply_market_filter(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Filter by allowed markets."""
    filtered = [s for s in symbols if s.market in config.allowed_markets]
    logger.info("Market filter: %d -> %d", len(symbols), len(filtered))
    return filtered


def apply_exclusion_filter(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Exclude symbols already on the active watchlist."""
    if not config.exclude_symbols:
        return symbols
    excluded = set(config.exclude_symbols)
    filtered = [s for s in symbols if s.symbol not in excluded]
    logger.info(
        "Exclusion filter: %d -> %d (excluded %d existing)",
        len(symbols),
        len(filtered),
        len(excluded),
    )
    return filtered


def apply_all_filters(
    symbols: list[UniverseSymbol],
    config: FilterConfig,
) -> list[UniverseSymbol]:
    """Apply all filters in sequence and cap at max_candidates.

    Filter order: market -> sector -> market_cap -> liquidity -> exclusion -> cap.
    """
    result = symbols
    result = apply_market_filter(result, config)
    result = apply_sector_filter(result, config)
    result = apply_market_cap_filter(result, config)
    result = apply_liquidity_filter(result, config)
    result = apply_exclusion_filter(result, config)

    if len(result) > config.max_candidates:
        # Sort by market cap descending, take top N
        result.sort(key=lambda s: s.market_cap_usd, reverse=True)
        result = result[: config.max_candidates]
        logger.info("Capped candidates to %d", config.max_candidates)

    logger.info("Final candidate count: %d", len(result))
    return result
