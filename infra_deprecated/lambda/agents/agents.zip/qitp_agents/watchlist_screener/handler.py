"""Watchlist Screener Agent — delegates to QITP generic handler."""
import os
os.environ.setdefault("AGENT_ID", "watchlist-screener")
from qitp_agents.app import handler  # noqa: E402, F401
