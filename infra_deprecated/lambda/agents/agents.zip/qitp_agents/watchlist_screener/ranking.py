"""Ranking engine for watchlist screener candidates.

Ranks filtered candidates by gap potential using a weighted scoring model.
Factors: historical gap frequency, average gap magnitude, volume stability,
sector momentum, and volatility characteristics.
"""

from __future__ import annotations

import logging
import math

from pydantic import BaseModel, Field

from qitp_agents.watchlist_screener.universe import UniverseSymbol

logger = logging.getLogger(__name__)


class GapHistoryStats(BaseModel):
    """Historical gap statistics for a symbol."""

    symbol: str
    total_gaps: int  # Number of gaps > threshold in lookback period
    avg_gap_pct: float  # Average gap magnitude
    max_gap_pct: float  # Maximum gap magnitude
    gap_up_ratio: float  # Proportion of gaps that were up
    avg_volume_ratio_on_gap: float  # Avg volume ratio on gap days
    gap_frequency_per_month: float  # Average gaps per month


class RankingWeights(BaseModel):
    """Weights for the gap potential scoring model."""

    gap_frequency: float = 0.30
    gap_magnitude: float = 0.25
    volume_stability: float = 0.20
    market_cap_score: float = 0.15
    sector_diversity: float = 0.10


class RankedCandidate(BaseModel):
    """A ranked candidate with scoring breakdown."""

    symbol: str
    name: str
    market: str
    sector: str
    overall_score: float = Field(ge=0.0, le=1.0)
    gap_frequency_score: float = Field(ge=0.0, le=1.0)
    gap_magnitude_score: float = Field(ge=0.0, le=1.0)
    volume_stability_score: float = Field(ge=0.0, le=1.0)
    market_cap_score: float = Field(ge=0.0, le=1.0)
    sector_diversity_score: float = Field(ge=0.0, le=1.0)
    gap_stats: GapHistoryStats | None = None
    recommendation: str  # "strong_add", "add", "monitor", "skip"


def compute_gap_frequency_score(stats: GapHistoryStats) -> float:
    """Score based on how often gaps occur.

    2+ gaps/month = 1.0, 0 gaps/month = 0.0. Log-scaled.
    """
    if stats.gap_frequency_per_month <= 0:
        return 0.0
    # Log scale: ln(1 + freq) / ln(3) capped at 1.0
    return min(1.0, math.log(1 + stats.gap_frequency_per_month) / math.log(3))


def compute_gap_magnitude_score(stats: GapHistoryStats) -> float:
    """Score based on average gap magnitude.

    5%+ avg = 1.0, 0% = 0.0. Linear.
    """
    return min(1.0, stats.avg_gap_pct / 5.0)


def compute_volume_stability_score(stats: GapHistoryStats) -> float:
    """Score based on volume consistency on gap days.

    High volume ratio on gap days = high conviction gaps.
    Ratio 3.0+ = 1.0, ratio 1.0 = 0.0.
    """
    if stats.avg_volume_ratio_on_gap <= 1.0:
        return 0.0
    return min(1.0, (stats.avg_volume_ratio_on_gap - 1.0) / 2.0)


def compute_market_cap_score(symbol: UniverseSymbol) -> float:
    """Score based on market cap — mid-cap sweet spot.

    Mid-cap ($10B-$100B) scores highest. Large and mega-cap score lower
    because gaps tend to be smaller. Small-cap excluded by filters.
    """
    cap_b = symbol.market_cap_usd / 1e9  # Convert to billions
    if cap_b < 5:
        return 0.3
    elif cap_b < 10:
        return 0.6
    elif cap_b < 50:
        return 1.0  # Sweet spot
    elif cap_b < 200:
        return 0.8
    elif cap_b < 1000:
        return 0.5
    else:
        return 0.3  # Mega-cap — gaps are rare


def compute_sector_diversity_score(
    symbol: UniverseSymbol,
    existing_sectors: dict[str, int],
    max_sector_count: int = 10,
) -> float:
    """Score based on sector diversification benefit.

    Under-represented sectors score higher to encourage portfolio diversity.
    """
    sector_count = existing_sectors.get(symbol.sector, 0)
    if sector_count == 0:
        return 1.0  # New sector — maximum diversity benefit
    return max(0.0, 1.0 - (sector_count / max_sector_count))


def rank_candidates(
    candidates: list[UniverseSymbol],
    gap_stats_map: dict[str, GapHistoryStats],
    existing_sectors: dict[str, int],
    weights: RankingWeights | None = None,
    top_n: int = 20,
) -> list[RankedCandidate]:
    """Rank candidates by gap potential score.

    Args:
        candidates: Filtered universe symbols.
        gap_stats_map: Historical gap stats keyed by symbol.
        existing_sectors: Current watchlist sector counts for diversity scoring.
        weights: Custom scoring weights (defaults used if None).
        top_n: Number of top candidates to return.

    Returns:
        Sorted list of RankedCandidate, highest score first.
    """
    if weights is None:
        weights = RankingWeights()

    ranked: list[RankedCandidate] = []

    for candidate in candidates:
        stats = gap_stats_map.get(candidate.symbol)

        if stats is None:
            # No gap history — assign minimum scores
            freq_score = 0.1
            mag_score = 0.1
            vol_score = 0.1
        else:
            freq_score = compute_gap_frequency_score(stats)
            mag_score = compute_gap_magnitude_score(stats)
            vol_score = compute_volume_stability_score(stats)

        cap_score = compute_market_cap_score(candidate)
        div_score = compute_sector_diversity_score(candidate, existing_sectors)

        overall = (
            weights.gap_frequency * freq_score
            + weights.gap_magnitude * mag_score
            + weights.volume_stability * vol_score
            + weights.market_cap_score * cap_score
            + weights.sector_diversity * div_score
        )

        # Recommendation thresholds
        if overall >= 0.7:
            recommendation = "strong_add"
        elif overall >= 0.5:
            recommendation = "add"
        elif overall >= 0.3:
            recommendation = "monitor"
        else:
            recommendation = "skip"

        ranked.append(
            RankedCandidate(
                symbol=candidate.symbol,
                name=candidate.name,
                market=candidate.market,
                sector=candidate.sector,
                overall_score=round(overall, 4),
                gap_frequency_score=round(freq_score, 4),
                gap_magnitude_score=round(mag_score, 4),
                volume_stability_score=round(vol_score, 4),
                market_cap_score=round(cap_score, 4),
                sector_diversity_score=round(div_score, 4),
                gap_stats=stats,
                recommendation=recommendation,
            )
        )

    ranked.sort(key=lambda r: r.overall_score, reverse=True)
    return ranked[:top_n]
