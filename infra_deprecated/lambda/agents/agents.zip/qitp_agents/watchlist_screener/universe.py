"""Stock universe providers for the watchlist screener.

Each universe provider returns a list of symbols with basic metadata
that the screener agent can then filter and rank.
"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

# Module-level constants for repeated string literals (S1192)
SECTOR_CONSUMER_DISCRETIONARY = "Consumer Discretionary"
SECTOR_COMMUNICATION_SERVICES = "Communication Services"
INDUSTRY_LAYER_1 = "Layer 1"


class UniverseSymbol(BaseModel):
    """A symbol from a stock universe with screening metadata."""

    symbol: str
    name: str
    market: str  # "us", "eu", "jp", "hk", "crypto"
    sector: str
    industry: str
    market_cap_usd: float
    avg_daily_volume: int
    currency: str
    exchange: str
    asset_type: str  # "stock", "etf", "crypto"
    tags: list[str] = Field(default_factory=list)


class UniverseProvider(ABC):
    """Abstract base class for stock universe providers."""

    @abstractmethod
    async def get_symbols(self) -> list[UniverseSymbol]:
        """Return all symbols in this universe."""
        ...

    @abstractmethod
    def universe_id(self) -> str:
        """Unique identifier for this universe."""
        ...


class SP500Provider(UniverseProvider):
    """S&P 500 universe provider.

    Loads constituents from S3 reference data or falls back to
    a static list for backtest mode.
    """

    def __init__(self, s3_client: Any = None, bucket: str = "qitp-historical-data") -> None:
        self._s3_client = s3_client
        self._bucket = bucket

    def universe_id(self) -> str:
        return "sp500"

    async def get_symbols(self) -> list[UniverseSymbol]:
        """Load S&P 500 constituents from S3 reference data."""
        try:
            if self._s3_client:
                return self._load_from_s3()
        except Exception:
            logger.warning("Failed to load S&P 500 from S3, using static fallback")

        return self._static_fallback()

    def _load_from_s3(self) -> list[UniverseSymbol]:
        """Load universe from S3 parquet reference file."""
        import io

        import pandas as pd

        response = self._s3_client.get_object(
            Bucket=self._bucket,
            Key="reference/sp500_constituents.parquet",
        )
        df = pd.read_parquet(io.BytesIO(response["Body"].read()))
        return [
            UniverseSymbol(
                symbol=row["symbol"],
                name=row["name"],
                market="us",
                sector=row["sector"],
                industry=row.get("industry", "Unknown"),
                market_cap_usd=row["market_cap"],
                avg_daily_volume=int(row["avg_volume"]),
                currency="USD",
                exchange="NYSE" if row.get("exchange") == "NYSE" else "NASDAQ",
                asset_type="stock",
            )
            for _, row in df.iterrows()
        ]

    def _static_fallback(self) -> list[UniverseSymbol]:
        """Minimal static fallback for testing."""
        # In production, this would be a full 500-symbol list from S3
        symbols = [
            ("AAPL", "Apple Inc.", "Technology", "Consumer Electronics", 3_000_000_000_000, 50_000_000, "NASDAQ"),
            ("MSFT", "Microsoft Corp.", "Technology", "Software", 2_800_000_000_000, 25_000_000, "NASDAQ"),
            (
                "AMZN",
                "Amazon.com Inc.",
                SECTOR_CONSUMER_DISCRETIONARY,
                "E-Commerce",
                1_800_000_000_000,
                40_000_000,
                "NASDAQ",
            ),  # noqa: E501
            ("NVDA", "NVIDIA Corp.", "Technology", "Semiconductors", 2_500_000_000_000, 35_000_000, "NASDAQ"),
            ("GOOGL", "Alphabet Inc.", SECTOR_COMMUNICATION_SERVICES, "Internet", 2_000_000_000_000, 20_000_000, "NASDAQ"),
            (
                "META",
                "Meta Platforms",
                SECTOR_COMMUNICATION_SERVICES,
                "Social Media",
                1_200_000_000_000,
                15_000_000,
                "NASDAQ",
            ),  # noqa: E501
            ("JPM", "JPMorgan Chase", "Financials", "Banks", 500_000_000_000, 10_000_000, "NYSE"),
            ("V", "Visa Inc.", "Financials", "Payments", 550_000_000_000, 7_000_000, "NYSE"),
            ("JNJ", "Johnson & Johnson", "Healthcare", "Pharmaceuticals", 400_000_000_000, 6_000_000, "NYSE"),
            ("XOM", "Exxon Mobil", "Energy", "Oil & Gas", 450_000_000_000, 12_000_000, "NYSE"),
        ]
        return [
            UniverseSymbol(
                symbol=s[0],
                name=s[1],
                market="us",
                sector=s[2],
                industry=s[3],
                market_cap_usd=s[4],
                avg_daily_volume=s[5],
                currency="USD",
                exchange=s[6],
                asset_type="stock",
            )
            for s in symbols
        ]


class STOXX600Provider(UniverseProvider):
    """STOXX Europe 600 universe provider."""

    def __init__(self, s3_client: Any = None, bucket: str = "qitp-historical-data") -> None:
        self._s3_client = s3_client
        self._bucket = bucket

    def universe_id(self) -> str:
        return "stoxx600"

    async def get_symbols(self) -> list[UniverseSymbol]:
        """Load STOXX 600 constituents."""
        try:
            if self._s3_client:
                return self._load_from_s3()
        except Exception:
            logger.warning("Failed to load STOXX 600 from S3, using static fallback")

        return self._static_fallback()

    def _load_from_s3(self) -> list[UniverseSymbol]:
        """Load from S3 reference data."""
        import io

        import pandas as pd

        response = self._s3_client.get_object(
            Bucket=self._bucket,
            Key="reference/stoxx600_constituents.parquet",
        )
        df = pd.read_parquet(io.BytesIO(response["Body"].read()))
        return [
            UniverseSymbol(
                symbol=row["symbol"],
                name=row["name"],
                market="eu",
                sector=row["sector"],
                industry=row.get("industry", "Unknown"),
                market_cap_usd=row["market_cap_usd"],
                avg_daily_volume=int(row["avg_volume"]),
                currency=row.get("currency", "EUR"),
                exchange=row.get("exchange", "XETRA"),
                asset_type="stock",
            )
            for _, row in df.iterrows()
        ]

    def _static_fallback(self) -> list[UniverseSymbol]:
        """Minimal static fallback."""
        symbols = [
            ("SAN.MC", "Banco Santander", "Financials", "Banks", 70_000_000_000, 30_000_000, "BME", "EUR"),
            ("ITX.MC", "Inditex", SECTOR_CONSUMER_DISCRETIONARY, "Apparel", 110_000_000_000, 5_000_000, "BME", "EUR"),
            ("SAP.DE", "SAP SE", "Technology", "Software", 250_000_000_000, 3_000_000, "XETRA", "EUR"),
            ("ASML.AS", "ASML Holding", "Technology", "Semiconductors", 350_000_000_000, 2_000_000, "AMS", "EUR"),
            ("NESN.SW", "Nestle SA", "Consumer Staples", "Food", 250_000_000_000, 4_000_000, "SIX", "CHF"),
        ]
        return [
            UniverseSymbol(
                symbol=s[0],
                name=s[1],
                market="eu",
                sector=s[2],
                industry=s[3],
                market_cap_usd=s[4],
                avg_daily_volume=s[5],
                currency=s[7],
                exchange=s[6],
                asset_type="stock",
            )
            for s in symbols
        ]


class Nikkei225Provider(UniverseProvider):
    """Nikkei 225 universe provider (Japan market)."""

    def __init__(self, s3_client: Any = None, bucket: str = "qitp-historical-data") -> None:
        self._s3_client = s3_client
        self._bucket = bucket

    def universe_id(self) -> str:
        return "nikkei225"

    async def get_symbols(self) -> list[UniverseSymbol]:
        """Load Nikkei 225 constituents."""
        # Always static fallback for now — S3 loading same pattern as SP500
        return self._static_fallback()

    def _static_fallback(self) -> list[UniverseSymbol]:
        symbols = [
            (
                "7203.T",
                "Toyota Motor",
                SECTOR_CONSUMER_DISCRETIONARY,
                "Automobiles",
                300_000_000_000,
                8_000_000,
                "TSE",
                "JPY",
            ),  # noqa: E501
            ("6758.T", "Sony Group", "Technology", "Electronics", 120_000_000_000, 5_000_000, "TSE", "JPY"),
            ("9984.T", "SoftBank Group", SECTOR_COMMUNICATION_SERVICES, "Telecom", 80_000_000_000, 10_000_000, "TSE", "JPY"),
            ("6861.T", "Keyence Corp", "Technology", "Instruments", 130_000_000_000, 1_000_000, "TSE", "JPY"),
            ("8306.T", "MUFG", "Financials", "Banks", 100_000_000_000, 15_000_000, "TSE", "JPY"),
        ]
        return [
            UniverseSymbol(
                symbol=s[0],
                name=s[1],
                market="jp",
                sector=s[2],
                industry=s[3],
                market_cap_usd=s[4],
                avg_daily_volume=s[5],
                currency=s[7],
                exchange=s[6],
                asset_type="stock",
            )
            for s in symbols
        ]


class CryptoTop100Provider(UniverseProvider):
    """Top 100 cryptocurrency universe provider."""

    def __init__(self, s3_client: Any = None, bucket: str = "qitp-historical-data") -> None:
        self._s3_client = s3_client
        self._bucket = bucket

    def universe_id(self) -> str:
        return "crypto_top100"

    async def get_symbols(self) -> list[UniverseSymbol]:
        """Load top 100 crypto assets."""
        return self._static_fallback()

    def _static_fallback(self) -> list[UniverseSymbol]:
        symbols = [
            ("BTC-USD", "Bitcoin", "Cryptocurrency", INDUSTRY_LAYER_1, 1_200_000_000_000, 30_000_000_000),
            ("ETH-USD", "Ethereum", "Cryptocurrency", INDUSTRY_LAYER_1, 400_000_000_000, 15_000_000_000),
            ("SOL-USD", "Solana", "Cryptocurrency", INDUSTRY_LAYER_1, 80_000_000_000, 3_000_000_000),
            ("BNB-USD", "Binance Coin", "Cryptocurrency", "Exchange", 60_000_000_000, 1_000_000_000),
            ("XRP-USD", "Ripple", "Cryptocurrency", "Payments", 30_000_000_000, 2_000_000_000),
        ]
        return [
            UniverseSymbol(
                symbol=s[0],
                name=s[1],
                market="crypto",
                sector=s[2],
                industry=s[3],
                market_cap_usd=s[4],
                avg_daily_volume=s[5],
                currency="USD",
                exchange="MULTI",
                asset_type="crypto",
            )
            for s in symbols
        ]


# --- Registry ---

UNIVERSE_REGISTRY: dict[str, type[UniverseProvider]] = {
    "sp500": SP500Provider,
    "stoxx600": STOXX600Provider,
    "nikkei225": Nikkei225Provider,
    "crypto_top100": CryptoTop100Provider,
}


def get_universe_provider(universe_id: str, **kwargs: Any) -> UniverseProvider:
    """Get a universe provider by ID.

    Args:
        universe_id: One of "sp500", "stoxx600", "nikkei225", "crypto_top100".
        **kwargs: Passed to the provider constructor (e.g., s3_client, bucket).

    Returns:
        UniverseProvider instance.

    Raises:
        ValueError: If universe_id is not recognized.
    """
    provider_cls = UNIVERSE_REGISTRY.get(universe_id)
    if not provider_cls:
        raise ValueError(f"Unknown universe '{universe_id}'. Available: {list(UNIVERSE_REGISTRY.keys())}")
    return provider_cls(**kwargs)
